
function Table_view() {

    return (
        <div>
            <h1>Table view</h1>

        </div>
    )
}

export default Table_view