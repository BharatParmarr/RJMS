function RoomDetails() {
    return (
        <div>RoomDetails</div>
    )
}

export default RoomDetails