import { useEffect, useState } from 'react';
import styled from 'styled-components';
import { TableComponent } from './component2/TableComponent';
import { ChartComponent } from './component2/ChartComponent';
import { useSpring, animated } from 'react-spring';
import { CircularProgress } from '@mui/material';
import { apis2 } from '../apis';

// Styled-components for page layout and styling
const PageContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  background-color: ${({ theme }) => theme.colors.background};
  color: ${({ theme }) => theme.colors.text};
`;

const Title = styled.h1`
  font-size: 2.5rem;
  margin-bottom: 20px;
  color: ${({ theme }) => theme.colors.primary};
`;

const Section = styled.div`
  margin: 20px 0;
  width: 80%;
`;

const LoaderContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 50vh;
`;

const DataAnalysisPage = () => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Fetch data from the Django API
        const fetchData = async () => {
            try {
                const response = await apis2.get('/data');
                setData(response.data);
                setLoading(false);
            } catch (error) {
                console.error('Error fetching data:', error);
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    // Spring animation for chart appearance
    const springProps = useSpring({ opacity: loading ? 0 : 1 });

    if (loading) {
        return (
            <LoaderContainer>
                <CircularProgress />
            </LoaderContainer>
        );
    }

    return (
        <PageContainer>
            <Title>Hospital Data Analysis</Title>

            {/* Appointments by Status Section */}
            <Section>
                <h2>Appointments by Status</h2>
                <animated.div style={springProps}>
                    <ChartComponent data={data.appointments_by_status} type="pie" />
                </animated.div>
            </Section>

            {/* Average Patient Age Section */}
            <Section>
                <h2>Average Patient Age</h2>
                <p>{data.average_patient_age ? data.average_patient_age.toFixed(2) : 'N/A'}</p>
            </Section>

            {/* Room Utilization Table */}
            <Section>
                <h2>Room Utilization</h2>
                <TableComponent data={data.room_utilization} columns={['Room Name', 'Total Appointments']} />
            </Section>

            {/* Bed Utilization Table */}
            <Section>
                <h2>Bed Utilization</h2>
                <TableComponent data={data.bed_utilization} columns={['Bed Name', 'Total Appointments']} />
            </Section>

            {/* Facility Usage Table */}
            <Section>
                <h2>Facility Usage</h2>
                <TableComponent data={data.facility_usage} columns={['Facility Name', 'Total Appointments']} />
            </Section>

            {/* Specialties Analysis Table */}
            <Section>
                <h2>Specialties Analysis</h2>
                <TableComponent data={data.specialties_analysis} columns={['Specialties', 'Total Appointments']} />
            </Section>
        </PageContainer>
    );
};

export default DataAnalysisPage;
