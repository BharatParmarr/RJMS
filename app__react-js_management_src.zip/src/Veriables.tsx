const Brand_name = "BizWayn";
const Brand_logo = "https://bizwayn.com/assets/images/logo.png";
const Brand_icon = "https://bizwayn.com/assets/images/logo.png";

const Brand_slogan = "The Business Way Management System";
const Brand_info = "BizWayn is a Business Management System that helps you to manage your business in a better way and grow your business.";


export { Brand_name, Brand_logo, Brand_icon, Brand_slogan, Brand_info };